package de.uniba.wiai.dsg.ajp.uebung1.fizzbuzz;

public class Main {
	
	//TODO: implement main method: instantiate a FizzBuzz and let it print some numbers

}
